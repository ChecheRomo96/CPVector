#ifndef CROSS_PLATFORM_VECTOR_SORTING_H
#define CROSS_PLATFORM_VECTOR_SORTING_H

	#include "CPVector_SortingDefinitions.h"
	#include "CPVector_SortingArray.h"
	#include "CPVector_SortingTemplates.h"

#endif//CROSS_PLATFORM_VECTOR_SORTING_H