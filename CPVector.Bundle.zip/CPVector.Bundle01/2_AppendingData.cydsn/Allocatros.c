/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "stdlib.h"

void* operator new(size_t size) { 
    return malloc(size); 
} 

void operator delete(void* ptr) {
    free(ptr); 
}

void * operator new[](size_t size) { 
    return malloc(size); 
} 

void operator delete[](void * ptr) 
{ 
    free(ptr); 
}

/* [] END OF FILE */
