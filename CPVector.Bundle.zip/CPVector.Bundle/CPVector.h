#ifndef CROSS_PLATFORM_VECTOR_H
#define CROSS_PLATFORM_VECTOR_H

	#include "CPVector_BuildSettings.h"
	#include "Sorting/CPVector_Sorting.h"
	#include "CPVector_Template.h"

#endif//CROSS_PLATFORM_STRING_H